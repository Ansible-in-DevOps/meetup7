/// <reference types="cypress" />

describe("TEST", function() {
    it("OPIS", function() {
        // odwiedzamy stronę
        cy.visit("https://www.ceneo.pl")
    })
})